package com.cg.capsstore.changepassword.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.changepassword.entities.Merchant;

public interface IChangePasswordMerchantRepo extends JpaRepository<Merchant, Integer> {

}

