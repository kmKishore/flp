package com.cg.capsstore.changepassword.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.changepassword.entities.Customer;

public interface IChangePasswordCustomerRepo extends JpaRepository<Customer, Integer> {

}
