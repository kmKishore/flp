package com.cg.capsstore.changepassword.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capsstore.changepassword.service.IChangePasswordService;

@RestController
public class ChangePasswordRest {

	@Autowired
	IChangePasswordService changePasswordService;
	
	public IChangePasswordService getChangePasswordService() {
		return changePasswordService;
	}

	public void setChangePasswordService(IChangePasswordService changePasswordService) {
		this.changePasswordService = changePasswordService;
	}

	@PostMapping("/changepasswordcustomer/{customerId}/{oldpassword}/{newpassword}/{confirmnewpassword}")
	public String changePasswordCustomer(@PathVariable("customerId") int customerId, @PathVariable("oldpassword") String oldpassword, @PathVariable("newpassword") String newpassword, @PathVariable("confirmnewpassword") String confirmnewpassword) {
		return changePasswordService.changePasswordCustomer(customerId, oldpassword, newpassword, confirmnewpassword);
	}
	
	@PostMapping("/changepasswordmerchant/{merchantId}/{oldpassword}/{newpassword}/{confirmnewpassword}")
	public String changePasswordMerchant(@PathVariable("merchantId") int merchantId, @PathVariable("oldpassword") String oldpassword, @PathVariable("newpassword") String newpassword, @PathVariable("confirmnewpassword") String confirmnewpassword) {
		return changePasswordService.changePasswordMerchant(merchantId, oldpassword, newpassword, confirmnewpassword);
	}
	
	@PostMapping("/changepasswordadmin/{adminId}/{oldpassword}/{newpassword}/{confirmnewpassword}")
	public String changePasswordAdmin(@PathVariable("adminId") int adminId, @PathVariable("oldpassword") String oldpassword, @PathVariable("newpassword") String newpassword, @PathVariable("confirmnewpassword") String confirmnewpassword) {
		return changePasswordService.changePasswordAdmin(adminId, oldpassword, newpassword, confirmnewpassword);
	}
}
