package com.cg.capsstore.changepassword.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capsstore.changepassword.entities.Admin;
import com.cg.capsstore.changepassword.entities.Customer;
import com.cg.capsstore.changepassword.entities.Merchant;
import com.cg.capsstore.changepassword.repo.IChangePasswordAdminRepo;
import com.cg.capsstore.changepassword.repo.IChangePasswordCustomerRepo;
import com.cg.capsstore.changepassword.repo.IChangePasswordMerchantRepo;

@Service
@Transactional
public class ChangePasswordServiceImpl implements IChangePasswordService {

	@Autowired
	IChangePasswordCustomerRepo changePasswordCustomerRepo;
	@Autowired
	IChangePasswordMerchantRepo changePasswordMerchantRepo;
	@Autowired
	IChangePasswordAdminRepo changePasswordAdminRepo;
	public IChangePasswordCustomerRepo getChangePasswordCustomerRepo() {
		return changePasswordCustomerRepo;
	}

	public void setChangePasswordCustomerRepo(IChangePasswordCustomerRepo changePasswordCustomerRepo) {
		this.changePasswordCustomerRepo = changePasswordCustomerRepo;
	}

	public IChangePasswordMerchantRepo getChangePasswordMerchantRepo() {
		return changePasswordMerchantRepo;
	}

	public void setChangePasswordMerchantRepo(IChangePasswordMerchantRepo changePasswordMerchantRepo) {
		this.changePasswordMerchantRepo = changePasswordMerchantRepo;
	}

	public IChangePasswordAdminRepo getChangePasswordAdminRepo() {
		return changePasswordAdminRepo;
	}

	public void setChangePasswordAdminRepo(IChangePasswordAdminRepo changePasswordAdminRepo) {
		this.changePasswordAdminRepo = changePasswordAdminRepo;
	}

	@Override
	public String changePasswordCustomer(int customerId, String oldpassword, String newpassword, String confirmnewpassword) {
		Customer customer=changePasswordCustomerRepo.getOne(customerId);
		String msg;
		if(customer.getCustomerPassword().equals(oldpassword) && newpassword.length()>=8 && confirmnewpassword.equals(newpassword)) {
			msg="Success! Password Succesfully Changed";
		} else {
			msg="Error! Password Cannot Be Changed";
		}
		return msg;
	}

	@Override
	public String changePasswordMerchant(int merchantId, String oldpassword, String newpassword, String confirmnewpassword) {
		Merchant merchant=changePasswordMerchantRepo.getOne(merchantId);
		String msg;
		if(merchant.getMerchantPassword().equals(oldpassword) && newpassword.length()>=8 && confirmnewpassword.equals(newpassword)) {
			msg="Success! Password Succesfully Changed";
		} else {
			msg="Error! Password Cannot Be Changed";
		}
		return msg;
	}

	@Override
	public String changePasswordAdmin(int adminId, String oldpassword, String newpassword, String confirmnewpassword) {
		Admin admin=changePasswordAdminRepo.getOne(adminId);
		String msg;
		if(admin.getAdminPassword().equals(oldpassword) && newpassword.length()>=8 && confirmnewpassword.equals(newpassword)) {
			msg="Success! Password Succesfully Changed";
		} else {
			msg="Error! Password Cannot Be Changed";
		}
		return msg;
	}

	
}
