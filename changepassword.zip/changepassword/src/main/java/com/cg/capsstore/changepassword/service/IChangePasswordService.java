package com.cg.capsstore.changepassword.service;

public interface IChangePasswordService {
	public String changePasswordCustomer(int customerId, String oldpassword, String newpassword, String confirmnewpassword);
	public String changePasswordMerchant(int merchantId, String oldpassword, String newpassword, String confirmnewpassword);
	public String changePasswordAdmin(int adminId, String oldpassword, String newpassword, String confirmnewpassword);
}
