package com.cg.capsstore.changepassword.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.changepassword.entities.Admin;

public interface IChangePasswordAdminRepo extends JpaRepository<Admin, Integer> {

}

