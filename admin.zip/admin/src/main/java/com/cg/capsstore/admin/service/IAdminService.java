package com.cg.capsstore.admin.service;

import java.util.List;

import com.cg.capsstore.admin.entities.Customer;
import com.cg.capsstore.admin.entities.Merchant;
import com.cg.capsstore.admin.entities.Product;

public interface IAdminService {
	public List<Customer> showCustomers();
	public List<Product> showInventory();
	public List<Merchant> showMerchants();
}
