package com.cg.capsstore.admin.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.cg.capsstore.admin.entities.Customer;
import com.cg.capsstore.admin.entities.Merchant;
import com.cg.capsstore.admin.entities.Product;
import com.cg.capsstore.admin.repo.ICustomerRepo;
import com.cg.capsstore.admin.repo.IMerchantRepo;
import com.cg.capsstore.admin.repo.IProductRepo;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	ICustomerRepo customerRepo;
	
	@Autowired
	IMerchantRepo merchantRepo;
	
	@Autowired
	IProductRepo productRepo;

	public ICustomerRepo getCustomerRepo() {
		return customerRepo;
	}

	public void setCustomerRepo(ICustomerRepo customerRepo) {
		this.customerRepo = customerRepo;
	}

	public IMerchantRepo getMerchantRepo() {
		return merchantRepo;
	}

	public void setMerchantRepo(IMerchantRepo merchantRepo) {
		this.merchantRepo = merchantRepo;
	}

	public IProductRepo getProductRepo() {
		return productRepo;
	}

	public void setProductRepo(IProductRepo productRepo) {
		this.productRepo = productRepo;
	}

	@Override
	public List<Customer> showCustomers() {
		return customerRepo.findAll();
	}
	
	@Override
	public List<Product> showInventory() {
		return productRepo.findAll();		
	}

	@Override
	public List<Merchant> showMerchants() {
		return merchantRepo.findAll();
	}

}
