package com.cg.capsstore.admin.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.admin.entities.Merchant;

public interface IMerchantRepo extends JpaRepository<Merchant, Integer> {

}
