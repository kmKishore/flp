package com.cg.capsstore.admin.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.admin.entities.Customer;

public interface ICustomerRepo extends JpaRepository<Customer, Integer> {

}
