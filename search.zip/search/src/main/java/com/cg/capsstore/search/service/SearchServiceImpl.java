package com.cg.capsstore.search.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capsstore.search.entities.Merchant;
import com.cg.capsstore.search.entities.Product;
import com.cg.capsstore.search.repo.IMerchantRepo;
import com.cg.capsstore.search.repo.IProductRepo;

@Service
@Transactional
public class SearchServiceImpl implements ISearchService {

	@Autowired
	IMerchantRepo merchantRepo;
	
	public IMerchantRepo getMerchantRepo() {
		return merchantRepo;
	}

	public void setMerchantRepo(IMerchantRepo merchantRepo) {
		this.merchantRepo = merchantRepo;
	}
	
	@Autowired
	IProductRepo productRepo;

	public IProductRepo getProductRepo() {
		return productRepo;
	}

	public void setProductRepo(IProductRepo productRepo) {
		this.productRepo = productRepo;
	}

	@Override
	public List<Product> searchProducts(String product) {
		List<Product> productlist=productRepo.findAll();
		List<Product> foundprodlist=null;
		for(Product prod: productlist) {
			if(prod.getProductName().equals(product)) {
				foundprodlist.add(prod);
			}
		}
		return foundprodlist;
	}

	@Override
	public List<Merchant> searchMerchants(String merchant) {
		List<Merchant> merchantlist=merchantRepo.findAll();
		List<Merchant> foundmerchantlist=null;
		for(Merchant mer: merchantlist) {
			if(mer.getMerchantName().equals(merchant)) {
				foundmerchantlist.add(mer);
			}
		}
		return foundmerchantlist;
	}

}
