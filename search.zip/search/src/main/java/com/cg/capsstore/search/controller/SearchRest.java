package com.cg.capsstore.search.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.capsstore.search.entities.Merchant;
import com.cg.capsstore.search.entities.Product;
import com.cg.capsstore.search.service.ISearchService;

@RestController
public class SearchRest {

	@Autowired
	ISearchService searchService;
	
	public ISearchService getSearchService() {
		return searchService;
	}

	public void setSearchService(ISearchService searchService) {
		this.searchService = searchService;
	}
	
	@GetMapping("/searchMerchants")
	public List<Merchant> showMerchants(String merchant) {
		return searchService.searchMerchants(merchant);
	}
	
	@GetMapping("/searchProducts")
	public List<Product> showInventory(String product){
		return searchService.searchProducts(product);
	}
}
