package com.cg.capsstore.search.service;

import java.util.List;

import com.cg.capsstore.search.entities.Merchant;
import com.cg.capsstore.search.entities.Product;

public interface ISearchService {
	public List<Product> searchProducts(String product);
	public List<Merchant> searchMerchants(String merchant);
}
