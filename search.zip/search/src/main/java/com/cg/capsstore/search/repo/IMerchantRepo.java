package com.cg.capsstore.search.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.capsstore.search.entities.Merchant;

public interface IMerchantRepo extends JpaRepository<Merchant, Integer> {

}
