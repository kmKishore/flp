package com.cg.capsstore.managingmerchant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagingmerchantApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagingmerchantApplication.class, args);
	}

}
