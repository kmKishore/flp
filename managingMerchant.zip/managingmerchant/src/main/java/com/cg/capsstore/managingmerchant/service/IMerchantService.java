package com.cg.capsstore.managingmerchant.service;

import com.cg.capsstore.managingmerchant.entities.Merchant;

public interface IMerchantService {
	public boolean removeMerchantById(int id);
	public int addMerchant(Merchant merchant);
}
