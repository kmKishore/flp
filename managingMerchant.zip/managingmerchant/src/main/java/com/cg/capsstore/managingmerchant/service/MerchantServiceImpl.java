package com.cg.capsstore.managingmerchant.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.cg.capsstore.managingmerchant.entities.Merchant;
import com.cg.capsstore.managingmerchant.repo.IMerchantRepo;

@Service
@Transactional
public class MerchantServiceImpl implements IMerchantService {

	@Autowired
	IMerchantRepo merchantRepo;
	
	public IMerchantRepo getMerchantRepo() {
		return merchantRepo;
	}

	public void setMerchantRepo(IMerchantRepo merchantRepo) {
		this.merchantRepo = merchantRepo;
	}

	@Override
	public boolean removeMerchantById(int id) {
		try {
			merchantRepo.deleteById(id);
		} catch (EmptyResultDataAccessException e) {
			// TODO Auto-generated catch block
			return false;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return false;
		}
		return true;
	}

	@Override
	public int addMerchant(Merchant merchant) {
		// TODO Auto-generated method stub
		merchantRepo.save(merchant);
		return merchant.getMerchantId();
	}

}
